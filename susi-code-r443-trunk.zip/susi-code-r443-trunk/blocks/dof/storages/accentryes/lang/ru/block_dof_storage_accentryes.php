<?php
    $string['title'] = 'Биллинг Проводки';
?>