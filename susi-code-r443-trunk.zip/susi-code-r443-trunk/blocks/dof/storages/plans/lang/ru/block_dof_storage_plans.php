<?php

$string['title'] = 'Темы и контрольные точки';
$string['page_main_name'] = 'Темы и контрольные точки';
?>