<?php

$string['title'] = 'Настройки';
$string['page_main_name'] = 'Настройки';
$string['config:autochooseteacher'] = 'Выбирать учителя автоматически';
$string['config:recommendedteacher'] = 'Использовать поле &quot;рекомендованный учитель&quot;';
$string['config:showallpitems'] = 'Отображать все планируемые предметы в меню, если в программе задана опция &quot;Плавающие учебные планы&quot;';
?>