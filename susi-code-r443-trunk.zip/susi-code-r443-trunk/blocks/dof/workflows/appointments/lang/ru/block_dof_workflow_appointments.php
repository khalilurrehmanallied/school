<?php
$string['title'] = 'Статусы назначения должностей с табельными номерами';
$string['page_main_name'] = 'Статусы назначения должностей с табельными номерами';
$string['status:plan'] = 'Черновик';
$string['status:active'] = 'Принято';
$string['status:canceled'] = 'Освобождено';
$string['status:patient'] = 'Больничный';
$string['status:vacation'] = 'Отпуск';
?>
