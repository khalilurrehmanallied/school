<?php
$string['title'] = 'Статусы учебных годов';
$string['page_main_name'] = 'Статусы приказов';
$string['status:requested'] = 'Заказан';
$string['status:executed'] = 'Исполнен';
$string['status:canceled'] = 'Отменен';
$string['status:archive'] = 'Архивирован';
?>
