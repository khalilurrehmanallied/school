<?php

$string['title'] = 'Наследование темы';
$string['page_main_name'] = 'Наследование темы';


?>