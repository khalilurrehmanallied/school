<?php
$string['title'] = 'Статусы доверенностей и мандатов';
$string['page_main_name'] = 'Статусы доверенностей и мандатов';
$string['status:draft'] = 'Черновик';
$string['status:active'] = 'Действует';
$string['status:archive'] = 'Архив';
?>