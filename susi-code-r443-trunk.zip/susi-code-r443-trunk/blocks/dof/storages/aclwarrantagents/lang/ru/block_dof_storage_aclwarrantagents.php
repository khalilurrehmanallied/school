<?php

$string['title'] = 'Применения доверенностей';
$string['page_main_name'] = 'Применения доверенностей';
?>