<?php

$string['title'] = 'YUI';
$string['page_main_name'] = 'Библиотека YUI';

?>