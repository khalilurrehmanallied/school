<?php
$string['title'] = 'Статусы оборудования';
$string['page_main_name'] = 'Статусы оборудования';
$string['status:active'] = 'Доступен';
$string['status:notavailable'] = 'Не доступен';
$string['status:scrapped'] = 'Списано';
$string['status:repairing'] = 'В ремонте';  
$string['status:deleted'] = 'Удалено';
?> 