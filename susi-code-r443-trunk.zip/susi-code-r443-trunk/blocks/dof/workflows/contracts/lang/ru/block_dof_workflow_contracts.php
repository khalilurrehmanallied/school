<?php
$string['title'] = 'Статусы договоров на обучение';
$string['page_main_name'] = 'Статусы договоров на обучение';
$string['status:tmp'] = 'Неподтвержденный';
$string['status:cancel'] = 'Отменен';
$string['status:new'] = 'Новый';
$string['status:clientsign'] = 'Подписан клиентом';
$string['status:studreg'] = 'Зарегистрирован ученик';
$string['status:wesign'] = 'Подписан нами';
$string['status:work'] = 'Оказание услуг';
$string['status:frozen'] = 'Приостановлен';
$string['status:archives'] = 'Расторгнут';

?>