<?php

$string['title'] = 'Виджеты';
$string['page_main_name'] = 'Виджеты - набор функций для дополнительного оформления.';
$string['proccessing'] = 'Идет обработка данных...';
$string['select'] = 'Выбрать';
$string['error:required_function_not_exists'] = 'Ошибка при выполнении ajax-запроса: в плагине $a->plugin отсутствует функция $a->function';
$string['autocomplete_empty'] = 'Отсутствует';
$string['autocomplete_create'] = 'Создать';
$string['autocomplete_rename'] = 'Переименовать в';
$string['pages_nav_page'] = 'Страница';
$string['pagination_select_limitnum'] = 'Записей на странице: ';

$string['actions_label'] = "Действия";
$string['status_link_button'] = "Перейти к истории статусов";
$string['current_status'] = "Текущий статус: ";

?>