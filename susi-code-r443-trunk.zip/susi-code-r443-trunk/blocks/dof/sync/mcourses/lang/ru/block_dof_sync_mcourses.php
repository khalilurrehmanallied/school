<?php
$string['title'] = 'Плагин работы с курсами Moodle';
$string['page_main_name'] = 'Плагин работы с курсами Moodle';

?>