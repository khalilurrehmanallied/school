<?php

$string['title'] = 'История статусов';
$string['page_main_name'] = 'История статусов';
$string[''] = '';
?>