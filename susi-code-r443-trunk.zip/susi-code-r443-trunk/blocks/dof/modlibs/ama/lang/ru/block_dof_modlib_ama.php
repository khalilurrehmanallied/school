<?php

$string['title'] = 'API работы с Moodle';
$string['page_main_name'] = 'API работы с Moodle';
$string[''] = '';

$string['newusernewpasswordshorttext'] = "{$a->link}
Логин: {$a->username}
Пароль: {$a->newpassword}";


$string['quiz_report_attempts'] = "Результаты теста";

?>