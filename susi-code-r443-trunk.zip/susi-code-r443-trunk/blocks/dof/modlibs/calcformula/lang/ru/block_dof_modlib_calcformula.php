<?php
$string['title'] = 'Формулы';
$string['page_main_name'] = 'Формулы';

?>