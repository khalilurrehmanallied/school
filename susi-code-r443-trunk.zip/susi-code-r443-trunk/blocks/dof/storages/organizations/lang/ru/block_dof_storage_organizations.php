<?php

$string['title'] = 'Организации';
$string['page_main_name'] = 'Организации';
?>