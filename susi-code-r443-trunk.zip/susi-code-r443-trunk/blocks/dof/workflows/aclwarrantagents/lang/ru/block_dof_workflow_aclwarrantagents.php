<?php
$string['title'] = 'Статусы применения доверенностей';
$string['page_main_name'] = 'Статусы применения доверенностей';
$string['status:draft'] = 'Черновик';
$string['status:active'] = 'Действует';
$string['status:archive'] = 'Архив';

?>