<?php

$string['title'] = 'Привязка к месту работы';
$string['page_main_name'] = 'Привязка к месту работы';
?>