<?php
$string['title'] = 'Статусы событий';
$string['page_main_name'] = 'Статусы событий';
$string['status:plan'] = 'Запланировано';
$string['status:completed'] = 'Состоялось';
$string['status:replaced'] = 'Заменено';
$string['status:canceled'] = 'Отменено';
$string['status:postponed'] = 'Отложено';
$string['status:implied'] = 'Подразумевалось';
$string['status:deleted'] = 'Удалено';

$string['acl_changestatus:to:cancel'] = "Право отменять урок";

?>