<?php
$string['title'] = 'Файловое хранилище';
$string['page_main_name'] = 'Файловое хранилище';
?>