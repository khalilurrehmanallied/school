<?php
$string['title'] = 'Статусы причин отсуствия';
$string['page_main_name'] = 'Статусы причин отсуствия';
$string['status:active'] = 'Активный';
$string['status:deleted'] = 'Удален';
?>