<?php
$string['title'] = 'Библиотека биллинга';
$string['page_main_name'] = 'Библиотека биллинга';

$string['main_account'] = 'Задолженность слушателей';
$string['name_account'] = 'Счет по договору {$a}';
?>