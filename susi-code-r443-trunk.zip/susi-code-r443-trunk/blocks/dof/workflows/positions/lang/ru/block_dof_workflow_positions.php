<?php
$string['title'] = 'Статусы должностей';
$string['page_main_name'] = 'Статусы должностей';
$string['status:plan'] = 'Черновик';
$string['status:active'] = 'Действует';
$string['status:canceled'] = 'Не используется';
?>
