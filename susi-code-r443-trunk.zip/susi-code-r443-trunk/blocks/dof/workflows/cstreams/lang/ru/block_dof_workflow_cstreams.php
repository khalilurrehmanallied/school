<?php
$string['title'] = 'Статусы предмето-класса';
$string['page_main_name'] = 'Статусы предмето-класса';
$string['status:plan'] = 'Запланирован';
$string['status:active'] = 'Идет';
$string['status:frozen'] = 'Приостановлен';
$string['status:cancel'] = 'Отменен';
$string['status:complete'] = 'Завершен';
?>