<?php
$string['title'] = 'Статусы учебных годов';
$string['page_main_name'] = 'Статусы учебных годов';
$string['status:plan'] = 'Запланированный';
$string['status:createstreams'] = 'Cозданы предмето-классы';
$string['status:createsbc'] = 'Cформированы ручные подписки';
$string['status:createschedule'] = 'Cформировано расписание';
$string['status:active'] = 'Идет предмето-класс';
$string['status:completed'] = 'Завершенный';
$string['status:canceled'] = 'Отменен';
?>
