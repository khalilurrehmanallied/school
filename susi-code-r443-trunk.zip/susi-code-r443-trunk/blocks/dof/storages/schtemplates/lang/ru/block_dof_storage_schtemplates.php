<?php

$string['title'] = 'Расписание учебной недели';
$string['page_main_name'] = 'Расписание учебной недели';

$string['tmpl_begin_date_was_changed'] = "В шаблоне с id={$a->id} изменена дата начала занятия на {$a->begin}";

?>