<?php

$string['title'] = 'Связь классов с предмето-классами';
$string['page_main_name'] = 'Связь классов с предмето-классами';
$string['full'] = "Полная";
$string['norequired'] = "Необязательный курс";
$string['nolink'] = "Нет связи";
?>