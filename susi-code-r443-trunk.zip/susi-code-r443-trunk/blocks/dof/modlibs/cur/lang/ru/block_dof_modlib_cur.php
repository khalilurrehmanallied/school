<?php
$string['title'] = 'Cur';
$string['page_main_name'] = 'Плагин modlib/cur  для блока &quot;Успеваемость&quot;';
$string['class_doesnot_exists'] = 'Класс $a не  существует';
$string['file_not_found'] = 'Файл не существует $a';
?>