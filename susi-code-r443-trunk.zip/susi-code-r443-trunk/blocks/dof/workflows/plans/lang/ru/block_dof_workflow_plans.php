<?php
$string['title'] = 'Статусы контрольных точек';
$string['page_main_name'] = 'Статусы контрольных точек';
$string['status:active'] = 'Действующая';
$string['status:checked'] = 'Пройденная';
$string['status:excluded'] = 'Временно исключена';
$string['status:deleted'] = 'Удалена';
$string['status:fixed'] = 'Зафиксирована';
$string['status:draft'] = 'Не подтверждена';
$string['status:information'] = 'Справочная';
$string['status:additional'] = 'Дополнительная оценка';
?>
