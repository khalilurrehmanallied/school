<?php
    $string['title'] = 'CRM Ссылки тегов';
?>