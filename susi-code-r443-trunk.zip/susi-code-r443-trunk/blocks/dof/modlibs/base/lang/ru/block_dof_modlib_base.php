<?php

$string['title'] = 'Базовые классы плагинов';
$string['page_main_name'] = 'Базовые классы плагинов';

?>