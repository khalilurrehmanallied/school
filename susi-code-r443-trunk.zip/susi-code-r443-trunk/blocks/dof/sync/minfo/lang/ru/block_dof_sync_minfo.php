<?php
$string['title'] = 'Плагин получения информации о курсе Moodle';
$string['page_main_name'] = 'Плагин получения информации о курсе Moodle';

?>