<?php
    $string['title'] = 'Биллинг Счета';
?>