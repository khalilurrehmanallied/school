<?php
$string['title'] = 'Статусы комплектов оборудовани';
$string['page_main_name'] = 'Статусы комплектов оборудования';
$string['status:active'] = 'Доступен';
$string['status:granted'] = 'Выдан';
$string['status:canceled'] = 'Расформирован';
$string['status:notavailable'] = 'Не доступен';
$string['status:deleted'] = 'Удален';
?> 