<?php

$string['title'] = 'Данные из отчетов';
$string['page_main_name'] = 'Данные из отчетов';
?>