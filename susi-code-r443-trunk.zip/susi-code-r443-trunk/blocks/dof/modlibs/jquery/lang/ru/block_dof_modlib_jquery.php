<?php

$string['title'] = 'Jquery';
$string['page_main_name'] = 'Библиотека jQuery';

?>