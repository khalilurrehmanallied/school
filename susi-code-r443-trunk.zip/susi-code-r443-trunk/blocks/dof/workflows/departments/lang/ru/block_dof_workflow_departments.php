<?php
$string['title'] = 'Статусы подразделений';
$string['page_main_name'] = 'Статусы подразделений';
$string['status:active'] = 'Активен';
$string['status:deleted'] = 'Удалён';
$string['status:draft'] = 'Черновик';
?>
