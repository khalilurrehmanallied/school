<?php

$string['title'] = 'Адреса';
$string['page_main_name'] = 'Адреса';

$string['postalcode'] = 'Почтовый индекс';
$string['country'] = 'Страна';
$string['region'] = 'Регион';
$string['district'] = 'Район';
$string['city'] = 'Населенный пункт';
$string['streetname'] = 'Название улицы';
$string['streettype'] = 'Тип улицы';
$string['number'] = 'Номер дома';
$string['gate'] = 'Подъезд';
$string['floor'] = 'Этаж';
$string['apartment'] = 'Квартира';
$string['latitude'] = 'Широта';
$string['longitude'] = 'Долгота';

$string['county'] = "Район";

?>