<?php

$string['title'] = 'Договоры с сотрудниками';
$string['page_main_name'] = 'Договоры с сотрудниками';
?>