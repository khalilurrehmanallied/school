<?php
$string['title'] = 'Комплекты оборудования';
$string['page_main_name'] = 'Комплекты оборудования';
$string['choose_category'] = 'Выберите категорию';
?>