<?php

$string['title'] = 'Документы об образовании';
$string['page_main_name'] = 'Документы об образовании';
?>