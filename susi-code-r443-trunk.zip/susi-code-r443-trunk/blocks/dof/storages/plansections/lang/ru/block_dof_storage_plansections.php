<?php

$string['title'] = 'Тематические разделы';
$string['page_main_name'] = 'Тематические разделы';


?>