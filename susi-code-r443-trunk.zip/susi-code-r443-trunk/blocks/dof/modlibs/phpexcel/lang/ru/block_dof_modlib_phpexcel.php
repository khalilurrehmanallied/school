<?php
$string['title'] = 'PHPExcel';
$string['page_main_name'] = 'Плагин для создания excel документов';

?>