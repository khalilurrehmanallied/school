<?php

$string['title'] = 'Полномочия';
$string['page_main_name'] = 'Полномочия';

$string['not_valid_objectid'] = "Передан невалидный идентификатор объекта в метод has_right()";

?>