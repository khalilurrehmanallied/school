<?php
$string['title'] = 'Категории ресурсов';
$string['page_main_name'] = 'Категории ресурсов';
?>