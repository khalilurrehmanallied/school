<?php
$string['title'] = 'CRM Комментарии';
?>