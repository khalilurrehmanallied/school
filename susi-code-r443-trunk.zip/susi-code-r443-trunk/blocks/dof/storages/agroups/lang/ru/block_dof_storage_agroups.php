<?php

$string['title'] = 'Классы';
$string['page_main_name'] = 'Классы';
$string['status:canceled'] = 'Расформирован';
$string['status:completed'] = 'Завершил обучение';
$string['status:formed'] = 'Сформирован';
$string['status:active'] = 'Обучается';
$string['status:plan'] = 'Новая';
$string['status:suspended'] = 'Приостановлена';
//$string[''] = '';

$string['save_programm_defaultname'] = 'Класс {$a->name}';

// ОШИБКИ
$string['error_agroup_not_found_id'] = 'Класс не найден. ID:{$a}';
$string['error_agroup_not_valid_status'] = 'Класс находится в неподдерживающимся статусе. ID:{$a}';
$string['error_person_not_found'] = 'Персона не найдена. ID:{$a}';
$string['error_adding_to_group'] = 'Невозможно добавить персону в класс';
$string['error_import_empty_data'] = 'Данные для импорта учебного класса не переданы';
$string['error_import_agroup_not_found'] = 'Указанный учебный класс не найден';
$string['error_import_agroup_multiple_found'] = 'По указанным данным найдено несколько учебных классов';
?>