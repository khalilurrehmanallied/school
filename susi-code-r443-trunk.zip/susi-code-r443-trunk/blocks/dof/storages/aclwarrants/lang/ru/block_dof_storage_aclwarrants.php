<?php

$string['title'] = 'Доверенности и мандаты';
$string['page_main_name'] = 'Доверенности и мандаты';
$string['standardrole'] = 'Стандартная роль';
$string['teacher'] = 'Учитель';
$string['manager'] = 'Управляющий';
$string['student'] = 'Учеников';
$string['methodist'] = 'Методист';
$string['parent'] = 'Законный представитель';
$string['root'] = 'Полный доступ (Администратор)';
$string['user'] = 'Авторизованный пользователь';
?>