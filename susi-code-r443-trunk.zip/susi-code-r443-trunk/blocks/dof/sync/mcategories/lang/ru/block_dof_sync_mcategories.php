<?php
$string['title'] = 'Плагин работы с категориями Moodle';
$string['page_main_name'] = 'Плагин работы с категориями Moodle';

$string['acl_view_category_content'] = 'Видеть электронные учебные материалы подразделения';
$string['acl_edit_category_content'] = 'Редактировать электронные учебные материалы подразделения';
$string['acl_manage_category_content'] = 'Управлять электронными учебными материалами подразделения';

?>