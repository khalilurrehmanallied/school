<?php 
$string['title'] = 'ВУЗ';
$string['page_main_name'] = 'ВУЗ';
$string['department'] = 'Подразделение';
$string['recordbook'] = 'Зачетная книжка';
$string['forstudent'] = 'Ученикам';
$string['forteacher'] = 'Учителям';
$string['formanager'] = 'Администрации';
$string['link_name_ages'] = 'Учебные периоды';
$string['link_name_agroups'] = 'Классы';
$string['link_name_cpassed'] = 'Изучаемые и пройденные предметы';
$string['link_name_cstreams'] = 'Предмето-классы';
$string['link_name_departments'] = 'Структурные подразделения';
$string['link_name_journal'] = 'Журнал';
$string['link_name_persons'] = 'Люди';
$string['link_name_plans'] = 'Тематическое планирование';
$string['link_name_programmitems'] = 'Предметы';
$string['link_name_programms'] = 'Программы';
$string['link_name_programmsbcs'] = 'Подписки на программы';
$string['link_name_recordbook'] = 'Зачетная книжка';
$string['link_name_employees'] = 'Сотрудники';
$string['link_name_sel'] = 'Договоры';
$string['link_name_learningorders'] = 'Приказы по контингенту';
$string['link_name_schedule'] = 'Шаблоны расписания';
$string['link_name_my'] = 'Войти в личный кабинет';
$string['link_name_participants'] = 'Участники';
$string['organization_structure'] = 'Структура организации';
$string['staff'] = 'Контингент';
$string['learning_programs'] = 'Учебные программы';
$string['learning_process'] = 'Предмето-класс';
$string['new_student'] = 'Новый договор';
$string['contracts'] = 'Договоры';
$string['general_information'] = 'Основная информация';
$string['manage_staff'] = 'Работа с контингентом';
$string['process_organizing'] = 'Организация предмето-класса';
$string['participants_cstreams'] = 'Учебный план учеников';
$string['import_cstreams'] = 'Импорт предмето-классов';
$string['teacher_load'] = 'Нагрузка учителей';
$string['link_name_cfg'] = 'Параметры конфигураций';
$string['link_name_inventory'] = 'Ресурсы';
$string['plugin_has_been_disabled_in_this_department'] = 'Плагин &quot;Ресурсы&quot; отключен в этом подразделении';
$string['link_name_metaprogrammitems'] = 'Метапредметы';
$string['order_change_teacher'] = 'Приказ на передачу нагрузки учителя';

?>

