<?php

$string['title'] = 'Учебные периоды';
$string['page_main_name'] = 'Учебные периоды';
?>