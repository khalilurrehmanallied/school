<?php
$string['title'] = 'Шаблоны документации (Templater)';
$string['page_main_name'] = 'Шаблоны документации';
$string['error_export_data'] = 'Ошибка получения данных для экспорта';
$string['error_export_format'] = 'Не найден обработчик экспорта в данный фомат ($a)';
$string['backward'] = 'назад';
?>