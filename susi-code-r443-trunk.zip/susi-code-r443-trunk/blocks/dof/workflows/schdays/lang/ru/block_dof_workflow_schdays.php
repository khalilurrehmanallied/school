<?php
$string['title'] = 'Статусы дней';
$string['page_main_name'] = 'Статусы дней';
$string['status:plan'] = 'Запланирован';
$string['status:active'] = 'Создано расписание';
$string['status:draft'] = 'Неполное расписание';
$string['status:completed'] = 'Отмечены уроки';
$string['status:fixed'] = 'Зафиксирован';
$string['status:deleted'] = 'Удален';
?>
