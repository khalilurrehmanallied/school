<?php
$string['title'] = 'Синхронизация персоналий';
$string['page_main_name'] = 'Синхронизация персоналий с пользователями moodle';
$string['user_already_exist'] = 'Пользователь moodle с таким email уже существует. Выберите другой email или синхронизируйте персону деканата с пользователем moodle';
?>