<?php
$string['title'] = 'Статусы вакансий';
$string['page_main_name'] = 'Статусы вакансий';
$string['status:plan'] = 'Черновик';
$string['status:active'] = 'Действует';
$string['status:canceled'] = 'Сокращена';
?>
