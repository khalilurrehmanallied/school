<?php

$string['title'] = 'Учебные программы';
$string['page_main_name'] = 'Учебные программы';

$string['error_programm_not_created'] = 'Учебная программа не создана';
$string['error_programm_not_found'] = 'Учебная программа не найдена. ID: {$a}';
$string['error_programm_changestatus'] = 'Не удалось сменить статус у программы. ID: {$a}';

$string['error_import_empty_data'] = 'Данные для импорта программы не переданы';
$string['error_import_programm_not_found'] = 'Указанная программа обучения не найдена';
$string['error_import_programm_multiple_found'] = 'По указанным данным найдено несколько программ обучения';
?>