<?php 
$string['title'] = 'Плагин Стандарт';
$string['page_main_name'] = 'Плагин &quot;Стандарт&quot; для блока &quot;Успеваемость&quot;';
$string['finish_install'] = 'Завершить установку';
$string['finish_install_readme'] = 'Блок успешно добавлен в Moodle. Для завершения установки нажмите кнопку';
$string['install_all'] = 'Установить все';
?>