<?php
$string['title'] = 'Статусы классов';
$string['page_main_name'] = 'Статусы классов';
$string['available'] = 'Доступные';
$string['status:canceled'] = 'Расформирован';
$string['status:completed'] = 'Завершил обучение';
$string['status:formed'] = 'Сформирован';
$string['status:active'] = 'Обучается';
$string['status:plan'] = 'Новый';
$string['status:suspend'] = 'Приостановлен';
$string['withstatus'] = 'Имеющие статус';
?>
