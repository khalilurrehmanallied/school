<?php
////////////////////////////////////////////////////////////////////////////
//                                                                        //
// NOTICE OF COPYRIGHT                                                    //
//                                                                        //
// Dean`s Office for Moodle                                               //
// Электронный деканат                                                    //
// <http://deansoffice.ru/>                                               //
//                                                                        //
// Copyright (C) 2008-2999  Alex Djachenko (Алексей Дьяченко)             //
// alex-pub@my-site.ru                                                    //
// Copyright (C) 2008-2999  Evgenij Cigancov (Евгений Цыганцов)           //
// Copyright (C) 2008-2999  Ilia Smirnov (Илья Смирнов)                   //
// Copyright (C) 2008-2999  Mariya Rojayskaya (Мария Рожайская)           //
//                                                                        //
// This program is free software: you can redistribute it and/or modify   //
// it under the terms of the GNU General Public License as published by   //
// the Free Software Foundation, either version 3 of the Licensen.        //
//                                                                        //
// This program is distributed in the hope that it will be useful,        //
// but WITHOUT ANY WARRANTY; without even the implied warranty of         //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          //
// GNU General Public License for more details.                           //
//                                                                        //
// You should have received a copy of the GNU General Public License      //
// along with this program.  If not, see <http://www.gnu.org/licenses/>.  //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
$string['title'] = 'Статусы изучаемых и пройденных курсов';
$string['page_main_name'] = 'Статусы изучаемых и пройденных курсов';

$string['status:plan'] = 'Запланирован';
$string['status:active'] = 'Идет обучение';
$string['status:suspend'] = 'Приостановлен';
$string['status:canceled'] = 'Отменен';
$string['status:completed'] = 'Завершен';
$string['status:reoffset'] = 'Перезачет из другой программы или уч. заведения';
$string['status:failed'] = 'Неуспешно завершен';
$string['status:academicdebt'] = 'Академическая разница';
    

$string['status:request'] = "Заявка";
$string['acl_manage_requests/teacher'] = "Модерировать заявки на запись в обучаемый учебный процесс";
$string['acl_manage_requests'] = "Модерировать заявки на запись в учебный процесс";

?>