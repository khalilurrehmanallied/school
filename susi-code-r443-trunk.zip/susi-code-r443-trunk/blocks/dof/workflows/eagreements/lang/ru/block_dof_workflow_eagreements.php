<?php
$string['title'] = 'Статусы договоров с сотрудниками';
$string['page_main_name'] = 'Статусы договоров с сотрудниками';
$string['status:plan'] = 'Черновик';
$string['status:active'] = 'Действует';
$string['status:canceled'] = 'Расторгнут';
?>
