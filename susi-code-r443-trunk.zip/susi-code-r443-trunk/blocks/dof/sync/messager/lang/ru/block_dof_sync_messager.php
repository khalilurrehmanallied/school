<?php
$string['title'] = 'Отправка сообщений';
$string['page_main_name'] = 'Отправка сообщений пользователям Moodle';
?>