<?php

$string['title'] = 'Назначение должности с табельными номерами';
$string['page_main_name'] = 'Назначение должности с табельными номерами';

$string['delete_person_can_edit'] = 'Записи, доступные для удаления: ';
$string['delete_person_cant_edit'] = 'Записи, не доступные для удаления: ';
?>