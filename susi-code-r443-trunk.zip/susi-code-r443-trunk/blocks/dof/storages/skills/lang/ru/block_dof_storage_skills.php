<?php
    $string['title'] = 'Дерево компетенций';
?>