<?php
$string['title'] = 'Статусы связей должностей с предметами';
$string['page_main_name'] = 'Статусы связей должностей с предметами';
$string['status:plan'] = 'Заявлена';
$string['status:active'] = 'Действует';
$string['status:canceled'] = 'Отменена';
?>
