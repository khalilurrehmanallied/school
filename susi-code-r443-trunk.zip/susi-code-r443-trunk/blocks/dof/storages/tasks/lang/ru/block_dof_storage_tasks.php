<?php
    $string['title'] = 'CRM Задачи';
    $string['default_task_title'] = 'Заголовок задачи';
    $string['default_task_about'] = '';
    
    /**** Ошибки ****/
    $string['error_incorrect_param_insert_not_object'] = 'Ошибка при добавлении задачи - передан не-объект';
    $string['error_insert_task'] = 'Ошибка при добавленн задачи';
    $string['error_no_taskid'] = 'Не передан ID задачи';
    $string['error_no_task'] = 'Не найдена задача';
    
?>