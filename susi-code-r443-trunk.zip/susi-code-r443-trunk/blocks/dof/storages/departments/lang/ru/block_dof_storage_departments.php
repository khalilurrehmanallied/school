<?php

$string['title'] = 'Подразделения школы';
$string['page_main_name'] = 'Подразделения школы';

$string['error_save_leaddepartment_equal'] = "Подразделение ссылается на самого себя";
$string['error_save_department_not_found'] = "Подразделение не найдено";
$string['error_save_department_undefined'] = "Не указаны данные для поиска подразделения";
$string['error_save_empty_data'] = "Данные для сохранения не переданы";
$string['error_save_invalid_data'] = "Ошибка сохранения подразделения";
$string['error_save_leaddepartment_children'] = "Перенос в дочернее подразделение недоступен";

?>