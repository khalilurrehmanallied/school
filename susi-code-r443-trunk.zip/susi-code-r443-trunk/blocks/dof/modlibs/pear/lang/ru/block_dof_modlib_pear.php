<?php
$string['title'] = 'Библиотеки PEAR';
$string['page_main_name'] = 'Библиотеки PEAR';
    
?>