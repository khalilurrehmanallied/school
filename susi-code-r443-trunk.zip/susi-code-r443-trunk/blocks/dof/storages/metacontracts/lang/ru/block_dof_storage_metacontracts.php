<?php

$string['title'] = 'Метаконтракты';
$string['page_main_name'] = 'Договора с классами';
$string['no_exist'] = 'Несуществующий метаконтракт!';