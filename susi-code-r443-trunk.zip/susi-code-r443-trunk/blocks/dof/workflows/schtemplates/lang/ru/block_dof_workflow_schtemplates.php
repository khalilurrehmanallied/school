<?php
$string['title'] = 'Статусы расписания учебной недели';
$string['page_main_name'] = 'Статусы расписания учебной недели';
$string['status:active'] = 'Включен';
$string['status:suspend'] = 'Приостановлен';
$string['status:deleted'] = 'Удален';
?>
