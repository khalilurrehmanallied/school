<?php

$string['title'] = 'Управление навигацией';
$string['page_main_name'] = 'Управление навигацией';
$string['backwards'] = 'назад';
$string['error:cannot_include_scripts'] = 'Ошибка: невозможно подключить файлы ( $a ): заголовок уже выведен';
$string['error:cannot_modify_bodytags'] = 'Онибка: невозможно модифbцировать body - заголовок  уже выведен';
$string['error_config_file_not_found'] = 'Файл конфигурации для позиции {$a} не найден';

?>