<?php
$string['title'] = 'Синхронизация компетенций';
$string['page_main_name'] = 'Синхронизация компетенций';

?>