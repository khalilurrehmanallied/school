<?php
$string['title'] = 'Отчеты по пользователям и курсам Moodle';
$string['page_main_name'] = 'Отчеты по пользователям и курсам Moodle';
$string['shortstudent'] = 'Краткий отчет по ученикам';
$string['shortteacher'] = 'Краткий отчет по ученикам';
$string['info'] = 'Информация';
$string['department'] = 'Подразделение';
$string['data_complete'] = 'Дата сборки';
$string['data_begin'] = 'Дата начала сбора';
$string['all_departs'] = 'Все подразделения';
$string['request_name'] = 'Дата заказа';

?>
